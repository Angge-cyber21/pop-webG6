-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 10, 2025 at 02:26 PM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `preorder pal`
--

-- --------------------------------------------------------

--
-- Table structure for table `dessert_orders`
--

DROP TABLE IF EXISTS `dessert_orders`;
CREATE TABLE IF NOT EXISTS `dessert_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dessert_name` varchar(100) NOT NULL,
  `price` int NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `order_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `dessert_orders`
--

INSERT INTO `dessert_orders` (`id`, `dessert_name`, `price`, `payment_method`, `order_time`) VALUES
(1, 'Leche Flan', 110, '', '2025-05-10 11:20:52'),
(2, 'Ice Cream', 80, '', '2025-05-10 11:28:18'),
(3, 'Apple Pie', 100, '', '2025-05-10 11:47:15'),
(4, 'Ice Cream', 80, '', '2025-05-10 12:26:44');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
